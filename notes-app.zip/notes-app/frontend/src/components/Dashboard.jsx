import React, { useState, useEffect } from "react";
import axios from "axios";
import NoteItem from "./NoteItem";

function Dashboard({ user, onLogout }) {
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState({ title: "", content: "" });
  const [editingNote, setEditingNote] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotes();
  }, []);

  const fetchNotes = async () => {
    try {
      const response = await axios.get("/api/notes");
      setNotes(response.data);
    } catch (error) {
      console.error("Error fetching notes:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateNote = async (e) => {
    e.preventDefault();
    if (!newNote.title.trim() || !newNote.content.trim()) return;

    try {
      const response = await axios.post("/api/notes", newNote);
      setNotes([response.data, ...notes]);
      setNewNote({ title: "", content: "" });
    } catch (error) {
      console.error("Error creating note:", error);
    }
  };

  const handleEditNote = async (noteId, updatedNote) => {
    try {
      const response = await axios.put(`/api/notes/${noteId}`, updatedNote);
      setNotes(
        notes.map((note) => (note._id === noteId ? response.data : note))
      );
      setEditingNote(null);
    } catch (error) {
      console.error("Error updating note:", error);
    }
  };

  const handleDeleteNote = async (id) => {
    if (!window.confirm("Are you sure you want to delete this note?")) return;

    try {
      await axios.delete(`/api/notes/${id}`);
      setNotes(notes.filter((note) => note._id !== id));
    } catch (error) {
      console.error("Error deleting note:", error);
    }
  };

  if (loading) {
    return <div className="loading">Loading notes...</div>;
  }

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div>
          <h1>My Notes</h1>
          <span className="user-info">Welcome, {user.name}</span>
        </div>
        <button onClick={onLogout} className="logout-btn">
          Logout
        </button>
      </header>

      <div className="dashboard-content">
        <form className="note-form" onSubmit={handleCreateNote}>
          <input
            type="text"
            placeholder="Note title..."
            value={newNote.title}
            onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
          />
          <textarea
            placeholder="Write your note here..."
            value={newNote.content}
            onChange={(e) =>
              setNewNote({ ...newNote, content: e.target.value })
            }
            rows="4"
          />
          <button type="submit">Add Note</button>
        </form>

        <div className="notes-grid">
          {notes.length === 0 ? (
            <div className="no-notes">
              <p>No notes yet. Create your first note above!</p>
            </div>
          ) : (
            notes.map((note) => (
              <NoteItem
                key={note._id}
                note={note}
                isEditing={editingNote === note._id}
                onEdit={(updatedNote) => handleEditNote(note._id, updatedNote)}
                onStartEdit={() => setEditingNote(note._id)}
                onCancelEdit={() => setEditingNote(null)}
                onDelete={() => handleDeleteNote(note._id)}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
