import React, { useState, useEffect } from "react";

function NoteItem({
  note,
  isEditing,
  onEdit,
  onStartEdit,
  onCancelEdit,
  onDelete,
}) {
  const [editData, setEditData] = useState({
    title: note.title,
    content: note.content,
  });

  useEffect(() => {
    if (isEditing) {
      setEditData({
        title: note.title,
        content: note.content,
      });
    }
  }, [isEditing, note]);

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (!editData.title.trim() || !editData.content.trim()) return;
    onEdit(editData);
  };

  const handleCancel = () => {
    setEditData({
      title: note.title,
      content: note.content,
    });
    onCancelEdit();
  };

  if (isEditing) {
    return (
      <div className="note-item editing">
        <form onSubmit={handleSave}>
          <input
            type="text"
            value={editData.title}
            onChange={(e) =>
              setEditData({ ...editData, title: e.target.value })
            }
            className="edit-title"
            placeholder="Note title"
            autoFocus
          />
          <textarea
            value={editData.content}
            onChange={(e) =>
              setEditData({ ...editData, content: e.target.value })
            }
            className="edit-content"
            placeholder="Note content"
            rows="4"
          />
          <div className="edit-actions">
            <button type="submit" className="save-btn">
              Save
            </button>
            <button type="button" onClick={handleCancel} className="cancel-btn">
              Cancel
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="note-item">
      <div className="note-header">
        <h3>{note.title}</h3>
        <div className="note-actions">
          <button onClick={onStartEdit} className="edit-btn" title="Edit note">
            ✎
          </button>
          <button onClick={onDelete} className="delete-btn" title="Delete note">
            ×
          </button>
        </div>
      </div>
      <p className="note-content">{note.content}</p>
      <div className="note-footer">
        <span className="note-date">
          Created: {formatDate(note.createdAt)}
          {note.updatedAt !== note.createdAt && (
            <span className="updated">
              {" "}
              • Updated: {formatDate(note.updatedAt)}
            </span>
          )}
        </span>
      </div>
    </div>
  );
}

export default NoteItem;
